package service;

import model.Usuario;
import repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    public void registrar(Usuario usuario) {
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuarioRepository.save(usuario);
    }

    public boolean existeUsuario(String nombre) {
        return usuarioRepository.findByNombreUsuario(nombre).isPresent();
    }

    public Usuario buscarPorNombre(String nombre) {
        return usuarioRepository.findByNombreUsuario(nombre)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }
}