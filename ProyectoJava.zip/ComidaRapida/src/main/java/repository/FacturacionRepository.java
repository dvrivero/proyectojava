package repository;

import model.Facturacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface FacturacionRepository extends JpaRepository<Facturacion, Integer> {
    Optional<Facturacion> findByPedidoIdPedido(Integer idPedido);
}