package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Menu")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSeleccion;

    @ManyToOne
    @JoinColumn(name = "idhamburguesa")
    private Hamburguesa hamburguesa;

    @ManyToOne
    @JoinColumn(name = "idPerro")
    private PerroCaliente perroCaliente;

    @ManyToOne
    @JoinColumn(name = "idSalchipapa")
    private Salchipapa salchipapa;

	public Integer getIdSeleccion() {
		return idSeleccion;
	}

	public void setIdSeleccion(Integer idSeleccion) {
		this.idSeleccion = idSeleccion;
	}

	public Hamburguesa getHamburguesa() {
		return hamburguesa;
	}

	public void setHamburguesa(Hamburguesa hamburguesa) {
		this.hamburguesa = hamburguesa;
	}

	public PerroCaliente getPerroCaliente() {
		return perroCaliente;
	}

	public void setPerroCaliente(PerroCaliente perroCaliente) {
		this.perroCaliente = perroCaliente;
	}

	public Salchipapa getSalchipapa() {
		return salchipapa;
	}

	public void setSalchipapa(Salchipapa salchipapa) {
		this.salchipapa = salchipapa;
	}
    
}