package model;

import jakarta.persistence.*;

@Entity
@Table(name = "usuario")
public class Usuario {

    @Id
    private String nombreUsuario;     // → nombre_usuario (PK)

    private String direccion;
    private String telefono;

    @Column(insertable = false, updatable = false)
    private Integer id;

    private String password;
    private String rol = "ROLE_USER";

    // Getters
    public String getNombreUsuario() { return nombreUsuario; }
    public String getDireccion()     { return direccion; }
    public String getTelefono()      { return telefono; }
    public Integer getId()           { return id; }
    public String getPassword()      { return password; }
    public String getRol()           { return rol; }

    // Setters
    public void setNombreUsuario(String v) { this.nombreUsuario = v; }
    public void setDireccion(String v)     { this.direccion = v; }
    public void setTelefono(String v)      { this.telefono = v; }
    public void setId(Integer v)           { this.id = v; }
    public void setPassword(String v)      { this.password = v; }
    public void setRol(String v)           { this.rol = v; }
}