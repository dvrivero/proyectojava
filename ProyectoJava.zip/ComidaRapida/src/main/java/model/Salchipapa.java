package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Salchipapa")
public class Salchipapa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSalchipapa;

    @Enumerated(EnumType.STRING)
    @Column(name = "Tamano")
    private Tamano tamano = Tamano.Mediano;

    @ManyToOne
    @JoinColumn(name = "idSalsa")
    private Salsas salsas;

    @ManyToOne
    @JoinColumn(name = "idAdicional")
    private Adicionales adicionales;

    public enum Tamano { Pequeño, Mediano, Grande }

	public Integer getIdSalchipapa() {
		return idSalchipapa;
	}

	public void setIdSalchipapa(Integer idSalchipapa) {
		this.idSalchipapa = idSalchipapa;
	}

	public Tamano getTamano() {
		return tamano;
	}

	public void setTamano(Tamano tamano) {
		this.tamano = tamano;
	}

	public Salsas getSalsas() {
		return salsas;
	}

	public void setSalsas(Salsas salsas) {
		this.salsas = salsas;
	}

	public Adicionales getAdicionales() {
		return adicionales;
	}

	public void setAdicionales(Adicionales adicionales) {
		this.adicionales = adicionales;
	}
   
}