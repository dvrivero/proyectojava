package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Adicionales")
public class Adicionales {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAdicional;

    private Boolean queso          = false;
    private Boolean chorizo        = false;
    private Boolean tocineta       = false;
    private Boolean papasFrancesas = false;
	public Integer getIdAdicional() {
		return idAdicional;
	}
	public void setIdAdicional(Integer idAdicional) {
		this.idAdicional = idAdicional;
	}
	public Boolean getQueso() {
		return queso;
	}
	public void setQueso(Boolean queso) {
		this.queso = queso;
	}
	public Boolean getChorizo() {
		return chorizo;
	}
	public void setChorizo(Boolean chorizo) {
		this.chorizo = chorizo;
	}
	public Boolean getTocineta() {
		return tocineta;
	}
	public void setTocineta(Boolean tocineta) {
		this.tocineta = tocineta;
	}
	public Boolean getPapasFrancesas() {
		return papasFrancesas;
	}
	public void setPapasFrancesas(Boolean papasFrancesas) {
		this.papasFrancesas = papasFrancesas;
	}
    
}