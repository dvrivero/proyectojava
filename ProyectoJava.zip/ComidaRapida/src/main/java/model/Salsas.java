package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Salsas")
public class Salsas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSalsa;

    private Boolean mayonesa = false;
    private Boolean ketchup  = false;
    private Boolean tratara  = false;
    private Boolean pina     = false;
    private Boolean bbq      = false;
	public Integer getIdSalsa() {
		return idSalsa;
	}
	public void setIdSalsa(Integer idSalsa) {
		this.idSalsa = idSalsa;
	}
	public Boolean getMayonesa() {
		return mayonesa;
	}
	public void setMayonesa(Boolean mayonesa) {
		this.mayonesa = mayonesa;
	}
	public Boolean getKetchup() {
		return ketchup;
	}
	public void setKetchup(Boolean ketchup) {
		this.ketchup = ketchup;
	}
	public Boolean getTratara() {
		return tratara;
	}
	public void setTratara(Boolean tratara) {
		this.tratara = tratara;
	}
	public Boolean getPina() {
		return pina;
	}
	public void setPina(Boolean pina) {
		this.pina = pina;
	}
	public Boolean getBbq() {
		return bbq;
	}
	public void setBbq(Boolean bbq) {
		this.bbq = bbq;
	}
    
}