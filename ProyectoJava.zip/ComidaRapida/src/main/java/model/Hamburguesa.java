package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Hamburguesa")
public class Hamburguesa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idHamburguesa;

    private Boolean lechuga = true;
    private Boolean tomate  = true;
    private Boolean pan     = true;
    private Boolean carne   = true;

    @ManyToOne
    @JoinColumn(name = "idSalsa")
    private Salsas salsas;

    @ManyToOne
    @JoinColumn(name = "idAdicional")
    private Adicionales adicionales;

	public Integer getIdHamburguesa() {
		return idHamburguesa;
	}

	public void setIdHamburguesa(Integer idHamburguesa) {
		this.idHamburguesa = idHamburguesa;
	}

	public Boolean getLechuga() {
		return lechuga;
	}

	public void setLechuga(Boolean lechuga) {
		this.lechuga = lechuga;
	}

	public Boolean getTomate() {
		return tomate;
	}

	public void setTomate(Boolean tomate) {
		this.tomate = tomate;
	}

	public Boolean getPan() {
		return pan;
	}

	public void setPan(Boolean pan) {
		this.pan = pan;
	}

	public Boolean getCarne() {
		return carne;
	}

	public void setCarne(Boolean carne) {
		this.carne = carne;
	}

	public Salsas getSalsas() {
		return salsas;
	}

	public void setSalsas(Salsas salsas) {
		this.salsas = salsas;
	}

	public Adicionales getAdicionales() {
		return adicionales;
	}

	public void setAdicionales(Adicionales adicionales) {
		this.adicionales = adicionales;
	}
    
}