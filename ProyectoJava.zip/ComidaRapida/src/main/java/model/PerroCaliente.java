package model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Perro_Caliente")
public class PerroCaliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idPerro;

    private Boolean salchicha = true;
    private Boolean panPerro  = true;

    @ManyToOne
    @JoinColumn(name = "idSalsa")
    private Salsas salsas;

    @ManyToOne
    @JoinColumn(name = "idAdicional")
    private Adicionales adicionales;

	public Integer getIdPerro() {
		return idPerro;
	}

	public void setIdPerro(Integer idPerro) {
		this.idPerro = idPerro;
	}

	public Boolean getSalchicha() {
		return salchicha;
	}

	public void setSalchicha(Boolean salchicha) {
		this.salchicha = salchicha;
	}

	public Boolean getPanPerro() {
		return panPerro;
	}

	public void setPanPerro(Boolean panPerro) {
		this.panPerro = panPerro;
	}

	public Salsas getSalsas() {
		return salsas;
	}

	public void setSalsas(Salsas salsas) {
		this.salsas = salsas;
	}

	public Adicionales getAdicionales() {
		return adicionales;
	}

	public void setAdicionales(Adicionales adicionales) {
		this.adicionales = adicionales;
	}
    
}