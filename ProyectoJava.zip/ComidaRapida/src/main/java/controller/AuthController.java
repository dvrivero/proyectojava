package controller;

import model.Usuario;
import service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/login")
    public String login(@RequestParam(required = false) String error,
                        @RequestParam(required = false) String logout,
                        Model model) {
        if (error  != null) model.addAttribute("error",  "Usuario o contraseña incorrectos.");
        if (logout != null) model.addAttribute("logout", "Sesión cerrada exitosamente.");
        return "login";
    }

    @GetMapping("/registro")
    public String registro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(@ModelAttribute Usuario usuario, Model model) {
        if (usuarioService.existeUsuario(usuario.getNombreUsuario())) {
            model.addAttribute("error", "Ese nombre de usuario ya existe.");
            return "registro";
        }
        usuarioService.registrar(usuario);
        return "redirect:/login?registro=true";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }
}